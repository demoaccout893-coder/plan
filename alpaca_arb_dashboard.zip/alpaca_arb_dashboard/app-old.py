from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import logging
from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest
from alpaca.trading.enums import OrderSide, TimeInForce
from alpaca.data.historical import CryptoHistoricalDataClient
from alpaca.data.requests import CryptoLatestTradeRequest
import config

app = Flask(__name__)
CORS(app)

alpaca = TradingClient(
    api_key=config.ALPACA_API_KEY,
    secret_key=config.ALPACA_SECRET_KEY,
    paper=config.ALPACA_PAPER
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

latest_prices = {}

def get_alpaca_price(symbol):
    """Fetch current price from Alpaca (symbol format: 'BTC/USD')"""
    try:
        client = CryptoHistoricalDataClient()
        request_params = CryptoLatestTradeRequest(symbol_or_symbols=symbol)
        trade = client.get_crypto_latest_trade(request_params)
        price = float(trade[symbol].price)
        latest_prices[symbol] = price
        return price
    except Exception as e:
        # Log the full exception trace to diagnose symbol issues
        logger.error(f"Error fetching Alpaca price for {symbol}: {e}", exc_info=True)
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/price/<path:symbol>')
def price(symbol):
    """Get Alpaca price for symbol (e.g., 'BTC/USD')"""
    price = get_alpaca_price(symbol)
    if price:
        return jsonify({'symbol': symbol, 'price': price})
    else:
        return jsonify({'error': 'Price not available'}), 500

@app.route('/api/trade', methods=['POST'])
def trade():
    data = request.get_json()
    symbol = data.get('symbol')
    side = data.get('side')
    if not symbol or not side:
        return jsonify({'error': 'Missing symbol or side'}), 400

    # Get current price to calculate quantity
    price = get_alpaca_price(symbol)
    if not price:
        return jsonify({'error': 'Cannot get current price'}), 500

    qty = round(config.TRADE_SIZE_USD / price, 4)
    if qty <= 0:
        return jsonify({'error': 'Quantity too small'}), 400

    order_side = OrderSide.BUY if side == 'buy' else OrderSide.SELL

    try:
        order_data = MarketOrderRequest(
            symbol=symbol,  # keep slash, e.g., "BTC/USD"
            qty=qty,
            side=order_side,
            time_in_force=TimeInForce.DAY
        )
        order = alpaca.submit_order(order_data)
        logger.info(f"Order placed: {side} {qty} {symbol}")
        return jsonify({
            'status': 'success',
            'order_id': order.id,
            'symbol': symbol,
            'side': side,
            'qty': qty
        })
    except Exception as e:
        logger.error(f"Order failed: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)