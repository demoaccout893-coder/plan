# Alpaca Paper Trading API credentials
ALPACA_API_KEY = 'PKLLA26WQ4YZOLILF7AXKE2LSW'
ALPACA_SECRET_KEY = '39GxatwktHY3pR1iVar8LeffMi1cNDKo9Etyzwe9J9kj'
ALPACA_PAPER = True  # Always True for paper trading

# Default trade size in USD
TRADE_SIZE_USD = 1000